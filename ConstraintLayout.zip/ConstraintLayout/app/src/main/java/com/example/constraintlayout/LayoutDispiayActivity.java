package com.example.constraintlayout;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class LayoutDispiayActivity extends AppCompatActivity {
    private static final String TAG=LayoutDispiayActivity.class.getSimpleName();
    static final String EXTRA_LAYOUT_ID=TAG+".layoutId";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle(getIntent().getStringExtra(Intent.EXTRA_TITLE));
        final int layoutId=getIntent().getIntExtra(EXTRA_LAYOUT_ID,0);
        setContentView(layoutId);
   }
}
