package com.example.constraintlayout;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    private static final String[] LIST_ITEMS = {"指定约束", "指定比例约束", "硬导线约束", "控件填充", "控件宽高比"};
    private static final int[] LAYOUT_IDS = {
            R.layout.layout_base, R.layout.layout_bias, R.layout.layout_guide_line,
            R.layout.layout_measure, R.layout.layout_aspect_ratio
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListView listView = (ListView) findViewById(R.id.activity_main);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, LIST_ITEMS);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //复用页面，显示不同的布局样式
                Intent intent = new Intent(MainActivity.this, LayoutDispiayActivity.class);
                intent.putExtra(Intent.EXTRA_TITLE, LIST_ITEMS[i]);
                intent.putExtra(LayoutDispiayActivity.EXTRA_LAYOUT_ID, LAYOUT_IDS[i]);
                startActivity(intent);
            }
        });
    }
}
