package com.example.appbarlayout;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SimpleFragment extends Fragment {
    private static final String ARG_SELECTION_NUM="arg_selection";

    private static final String[] TEXTS={
      "黄美英（Tiffany），1989年8月1日出生于美国加利福尼亚州旧金山市，韩国女歌手、主持人，女子演唱团体少女时代成员之一。2004年，黄美英在洛杉矶参加“S.M. casting System”选秀后进入韩国SM娱乐有限公司成为旗下练习生。2007年8月以演唱团体少女时代正式出道，担任主唱以及副领舞的职务。2009年凭借歌曲《By Myself》入围“第11届Mnet亚洲音乐大奖”最佳OST奖提名。" ,
      "金泰妍（Taeyeon），1989年3月9日出生于韩国全罗北道全州市，韩国女歌手、主持人，女子演唱团体少女时代成员之一。2004年在第八届SM青少年选拔大赛歌王中夺得第一名，进入韩国SM娱乐有限公司开始练习生生涯。2007年8月以演唱团体少女时代成员身份正式出道。2008年为韩国KBS电视台电视剧《快刀洪吉童》演唱主题曲《如果》；同年12月凭借歌曲《听得见吗》获得第23届韩国金唱片大奖人气奖。2012年与黄美英、徐珠贤组成了少女时代的小分队组合“TaeTiSeo”。",
      "林允儿（Yoona），1990年5月30日出生于韩国首尔，韩国女歌手、演员、主持人，女子演唱团体少女时代成员之一。2002年，林允儿被韩国SM娱乐有限公司发掘，正式进入SM公司成为旗下练习生。2007年8月5日以演唱团体少女时代正式出道。2008年在电视连续剧《你是我的命运》担任女主角，凭借该剧获得第45届百想艺术大赏最佳新人女演员奖。2009年参演电视剧《乞丐变王子》；同年凭借电视剧《你是我的命运》获得百想艺术大奖最佳新人女演员奖。"
    };
    @BindView(R.id.main_tv_text)
    TextView mTvText;

    public SimpleFragment(){

    }

    public static SimpleFragment newInstance(int selectionNum){
        SimpleFragment simpleFragment=new SimpleFragment();
        Bundle args=new Bundle();
        args.putInt(ARG_SELECTION_NUM,selectionNum);
        simpleFragment.setArguments(args);
        return simpleFragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_main,container,false);
        ButterKnife.bind(this,view);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mTvText=(TextView)view.findViewById(R.id.main_tv_text);
        mTvText.setText(TEXTS[getArguments().getInt(ARG_SELECTION_NUM)]);
    }
}
