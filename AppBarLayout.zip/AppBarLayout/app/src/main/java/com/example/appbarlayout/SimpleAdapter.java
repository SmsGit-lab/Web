package com.example.appbarlayout;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class SimpleAdapter extends FragmentPagerAdapter {

    private static final Section[] SECTIONS={
            new Section("Tiffany" ,R.drawable.tiffany),
            new Section("Taeyeon" ,R.drawable.taeyeon),
            new Section("Yoona" ,R.drawable.yoona),
    };
    public SimpleAdapter(FragmentManager fm){
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        return SimpleFragment.newInstance(position);
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        if(position>=0&&position<SECTIONS.length){
            return SECTIONS[position].getTitle();
        }
        return null;
    }

    @Override
    public int getCount() {
        return SECTIONS.length;
    }

public @DrawableRes
int getDrawable(int position){
        if (position>=0&&position<SECTIONS.length){
            return SECTIONS[position].getDrawable();
        }
        return -1;
}
    // 存储类
    private static final class Section {
        private final String mTitle; // 标题
        private final @DrawableRes int mDrawable; // 图片

        public Section(String title, int drawable) {
            mTitle = title;
            mDrawable = drawable;
        }

        public String getTitle() {
            return mTitle;
        }

        public int getDrawable() {
            return mDrawable;
        }
    }
}
