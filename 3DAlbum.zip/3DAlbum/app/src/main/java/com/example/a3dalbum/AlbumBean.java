package com.example.a3dalbum;

public class AlbumBean {
    public int imgResId;        //图片的ID
    public int titleResId;      //图片标题ID
    public AlbumBean(int imgResId,int titleResId){
        this.imgResId=imgResId;
        this.titleResId=titleResId;
    }
}
