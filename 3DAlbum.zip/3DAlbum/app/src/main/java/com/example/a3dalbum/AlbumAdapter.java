package com.example.a3dalbum;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import java.util.ArrayList;

public class AlbumAdapter extends BaseAdapter {
    private ArrayList<AlbumBean> dataList=new ArrayList<>();
    private Context mContext;
    public AlbumAdapter(Context context){
        mContext=context;
    }

    public void setData(ArrayList<AlbumBean>dataList) {
        this.dataList = dataList;
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public Object getItem(int i) {
        return dataList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view==null){
            LayoutInflater inflater=(LayoutInflater) mContext.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view=inflater.inflate(R.layout.item_album,null);
            ViewHolder viewHolder=new ViewHolder();
            viewHolder.iv_img=(ImageView)view.findViewById(R.id.iv_img);
            view.setTag(viewHolder);
        }
        ViewHolder holder=(ViewHolder)view.getTag();
        holder.iv_img.setImageResource(dataList.get(i).imgResId);
        return view;

    }
    public class ViewHolder{
        public ImageView iv_img;
    }
}
