package com.itheima.coverflow.ui.interfaces;


public interface IRemoveFromAdapter{
	void removeItemFromAdapter(int position);
}
